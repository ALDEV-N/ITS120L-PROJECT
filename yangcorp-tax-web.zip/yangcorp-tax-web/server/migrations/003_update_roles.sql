DELETE FROM roles
WHERE name NOT IN ('Client', 'Accountant', 'Admin');

INSERT OR IGNORE INTO roles (name, description) VALUES
  ('Client', 'Client portal user'),
  ('Accountant', 'Accounting or tax professional'),
  ('Admin', 'Administrative or operations lead');


