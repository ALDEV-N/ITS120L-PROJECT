CREATE TABLE IF NOT EXISTS data_uploads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  uploader_user_id INTEGER NOT NULL,
  client_id INTEGER,
  original_filename TEXT NOT NULL,
  stored_filename TEXT NOT NULL,
  row_count INTEGER DEFAULT 0,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (uploader_user_id) REFERENCES users(id),
  FOREIGN KEY (client_id) REFERENCES clients(id)
);

CREATE TABLE IF NOT EXISTS financial_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  upload_id INTEGER NOT NULL,
  client_id INTEGER NOT NULL,
  tax_year INTEGER NOT NULL,
  revenue REAL DEFAULT 0,
  expenses REAL DEFAULT 0,
  deductions REAL DEFAULT 0,
  payments REAL DEFAULT 0,
  net_income REAL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (upload_id) REFERENCES data_uploads(id),
  FOREIGN KEY (client_id) REFERENCES clients(id)
);

CREATE TABLE IF NOT EXISTS ai_forecasts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  upload_id INTEGER NOT NULL,
  client_id INTEGER NOT NULL,
  tax_year INTEGER NOT NULL,
  projected_liability REAL,
  projected_refund REAL,
  summary TEXT,
  generated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (upload_id) REFERENCES data_uploads(id),
  FOREIGN KEY (client_id) REFERENCES clients(id)
);

CREATE TABLE IF NOT EXISTS ai_anomalies (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  upload_id INTEGER NOT NULL,
  client_id INTEGER NOT NULL,
  description TEXT NOT NULL,
  severity TEXT NOT NULL,
  score REAL,
  generated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (upload_id) REFERENCES data_uploads(id),
  FOREIGN KEY (client_id) REFERENCES clients(id)
);

CREATE INDEX IF NOT EXISTS idx_financial_records_client_year ON financial_records (client_id, tax_year);
CREATE INDEX IF NOT EXISTS idx_ai_forecasts_client_year ON ai_forecasts (client_id, tax_year);
CREATE INDEX IF NOT EXISTS idx_ai_anomalies_client ON ai_anomalies (client_id);
