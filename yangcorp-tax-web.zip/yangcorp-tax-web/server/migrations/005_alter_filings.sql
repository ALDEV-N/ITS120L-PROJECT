ALTER TABLE filings ADD COLUMN amount_due REAL DEFAULT 0;


