import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import path from 'path';
import fs from 'fs';
import multer from 'multer';
import session from 'express-session';
import connectSqlite3 from 'connect-sqlite3';
import { fileURLToPath } from 'url';
import { ensureMigrations, getDb } from './lib/db.js';
import { seedDatabase } from './lib/seed.js';
import {
  createUser,
  authenticate,
  requireAuth,
  requireRole,
  getUserById
} from './lib/auth.js';
import {
  parseFinancialCsv,
  persistFinancialUpload,
  latestUploads,
  buildFinancialSnapshot,
  removeUploadRecords
} from './lib/finance.js';
import {
  generateClientForecast,
  generateAdminInsights,
  generateAccountantInsights,
  persistForecast,
  getAggregatedFinancialData,
  getClientFinancialDataForAccountant
} from './lib/ai.js';

const HF_TOKEN = process.env.HF_TOKEN;
const HF_MODEL = process.env.HF_MODEL || 'meta-llama/Meta-Llama-3-8B-Instruct';
const HF_URL = `https://api-inference.huggingface.co/models/${HF_MODEL}`;

async function callHuggingFace(prompt, parameters = {}) {
  if (!HF_TOKEN) {
    throw new Error('missing_hf_token');
  }
  const response = await fetch(HF_URL, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${HF_TOKEN}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      inputs: prompt,
      parameters: {
        max_new_tokens: 320,
        temperature: 0.35,
        ...parameters
      }
    })
  });
  if (!response.ok) {
    const body = await response.text();
    throw new Error(`hf_error:${response.status}:${body}`);
  }
  const data = await response.json();
  if (Array.isArray(data)) {
    return data[0]?.generated_text || data[0]?.text || '';
  }
  return data.generated_text || data.text || '';
}

function extractJsonBlock(text) {
  if (!text) return null;
  const match = text.match(/\{[\s\S]*\}/);
  if (!match) return null;
  try {
    return JSON.parse(match[0]);
  } catch (err) {
    return null;
  }
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const SQLiteStore = connectSqlite3(session);
const SESSION_SECRET = process.env.SESSION_SECRET || 'dev-secret-change-me';

const app = express();
const PORT = process.env.PORT || 5175;
const STATIC_DIR = path.resolve(__dirname, '..');
const DATA_DIR = path.resolve(__dirname, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const upload = multer({ dest: UPLOAD_DIR });

app.use((req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
});

app.use(morgan('dev'));
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(
  session({
    store: new SQLiteStore({
      db: 'sessions.db',
      dir: DATA_DIR
    }),
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      maxAge: 1000 * 60 * 60 * 24,
      secure: false
    }
  })
);

await ensureMigrations();
await seedDatabase();

const roleToDashboard = {
  Admin: 'pages/dashboard-admin.html',
  Accountant: 'pages/dashboard-accountant.html',
  Client: 'pages/dashboard-client.html'
};

app.get('/api/health', (req, res) => {
  res.json({ ok: true, status: 'healthy', user: req.session?.user ?? null });
});

app.get('/api/me', (req, res) => {
  res.json({ user: req.session?.user ?? null });
});

app.post('/auth/signup', async (req, res) => {
  try {
    const { full_name, email, password, role, firm_name, phone } = req.body;
    if (!full_name || !email || !password || !role) {
      return res.status(400).send('Missing required fields');
    }
    const user = await createUser({ full_name, email, password, role });
    const db = getDb();
    if (role === 'Client') {
      db.prepare(
        `INSERT INTO clients (firm_user_id, name, contact_email, contact_phone)
         VALUES (@firm_user_id, @name, @contact_email, @contact_phone)`
      ).run({
        firm_user_id: null,
        name: firm_name || `${full_name}'s Company`,
        contact_email: email,
        contact_phone: phone || null
      });
    }
    req.session.user = user;
    res.redirect('/dashboard');
  } catch (err) {
    const error = err.message;
    if (error === 'email_taken') {
      return res.status(400).send('Email already registered.');
    }
    if (error === 'invalid_role') {
      return res.status(400).send('Invalid role selected.');
    }
    console.error(err);
    res.status(500).send('Failed to create account.');
  }
});

app.post('/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).send('Missing credentials.');
    }
    const user = await authenticate(email, password);
    req.session.user = user;
    const db = getDb();
    db.prepare('UPDATE users SET last_login_at = datetime(\'now\') WHERE id = ?').run(user.id);
    res.redirect('/dashboard');
  } catch (err) {
    if (err.message === 'invalid_credentials') {
      return res.status(401).send('Invalid email or password.');
    }
    console.error(err);
    res.status(500).send('Login failed.');
  }
});

app.post('/auth/logout', requireAuth, (req, res) => {
  req.session.destroy(err => {
    res.clearCookie('connect.sid');
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'logout_failed' });
    }
    if (req.accepts('json')) {
      return res.json({ ok: true });
    }
    res.redirect('/pages/login.html');
  });
});

app.post('/api/inquiries', (req, res) => {
  const { name, email, message } = req.body || {};
  if (!name || !email) {
    return res.status(400).json({ ok: false, error: 'name and email are required' });
  }
  try {
    const db = getDb();
    const stmt = db.prepare(
      `INSERT INTO inquiries (name, email, message) VALUES (@name, @email, @message)`
    );
    const info = stmt.run({ name, email, message: message || null });
    res.status(201).json({ ok: true, id: info.lastInsertRowid });
  } catch (e) {
    res.status(500).json({ ok: false, error: 'failed_to_create' });
  }
});

app.get('/dashboard', requireAuth, (req, res) => {
  const file = roleToDashboard[req.session.user.role] || roleToDashboard.Client;
  res.sendFile(path.join(STATIC_DIR, file));
});

app.get('/pages/dashboard-admin.html', requireRole('Admin'), (req, res) => {
  res.sendFile(path.join(STATIC_DIR, 'pages/dashboard-admin.html'));
});
app.get('/pages/dashboard-accountant.html', requireRole('Accountant'), (req, res) => {
  res.sendFile(path.join(STATIC_DIR, 'pages/dashboard-accountant.html'));
});
app.get('/pages/dashboard-client.html', requireRole('Client'), (req, res) => {
  res.sendFile(path.join(STATIC_DIR, 'pages/dashboard-client.html'));
});

app.get('/api/dashboard/summary', requireAuth, (req, res) => {
  const { role, id } = req.session.user;
  try {
    if (role === 'Admin') {
      return res.json({ role, user: req.session.user, data: getAdminDashboardData() });
    }
    if (role === 'Accountant') {
      return res.json({ role, user: req.session.user, data: getAccountantDashboardData(id) });
    }
    return res.json({ role, user: req.session.user, data: getClientDashboardData(id) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'dashboard_failed' });
  }
});

app.get('/api/dashboard/ai/admin', requireRole('Admin'), async (req, res) => {
  try {
    const data = getAdminDashboardData();
    const financialData = getAggregatedFinancialData();
    const insights = await generateAdminInsights({ 
      metrics: data.metrics, 
      alerts: data.alerts, 
      financialData,
      callModel: callHuggingFace 
    });
    res.json(insights);
  } catch (err) {
    if (err.message === 'missing_hf_token') {
      return res.status(503).json({ error: 'AI token missing on server.' });
    }
    console.error(err);
    res.status(502).json({ error: 'ai_generation_failed' });
  }
});

app.get('/api/dashboard/ai/accountant', requireRole('Accountant'), async (req, res) => {
  try {
    const data = getAccountantDashboardData(req.session.user.id);
    const financialData = getClientFinancialDataForAccountant(req.session.user.id);
    const insights = await generateAccountantInsights({ 
      worklist: data.worklist, 
      clients: data.clients, 
      financialData,
      callModel: callHuggingFace 
    });
    res.json(insights);
  } catch (err) {
    if (err.message === 'missing_hf_token') {
      return res.status(503).json({ error: 'AI token missing on server.' });
    }
    console.error(err);
    res.status(502).json({ error: 'ai_generation_failed' });
  }
});

app.get('/api/dashboard/ai/client', requireRole('Client'), async (req, res) => {
  try {
    const db = getDb();
    const user = getUserById(req.session.user.id);
    const client = db.prepare('SELECT id FROM clients WHERE contact_email = ?').get(user.email);
    if (!client) {
      return res.json({ insights: [], actions: [], forecast: {} });
    }
    const existing = db
      .prepare(
        `SELECT * FROM ai_forecasts WHERE client_id = ? ORDER BY generated_at DESC LIMIT 1`
      )
      .get(client.id);
    if (existing) {
      const anomalies = db
        .prepare(
          `SELECT description, severity, score, generated_at
           FROM ai_anomalies WHERE client_id = ? ORDER BY generated_at DESC LIMIT 10`
        )
        .all(client.id);
      return res.json({
        insights: existing.summary ? [existing.summary] : [],
        actions: anomalies.map(a => a.description),
        forecast: {
          next_tax_year: existing.tax_year,
          projected_liability: existing.projected_liability,
          projected_refund: existing.projected_refund
        }
      });
    }
    const forecast = await generateClientForecast({ clientId: client.id, callModel: callHuggingFace });
    res.json(forecast);
  } catch (err) {
    if (err.message === 'missing_hf_token') {
      return res.status(503).json({ error: 'AI token missing on server.' });
    }
    console.error(err);
    res.status(502).json({ error: 'ai_generation_failed' });
  }
});

app.get('/api/clients', requireAnyRole('Admin', 'Accountant'), (req, res) => {
  const db = getDb();
  let clients;
  if (req.session.user.role === 'Accountant') {
    clients = db
      .prepare('SELECT * FROM clients WHERE firm_user_id = ? ORDER BY created_at DESC')
      .all(req.session.user.id);
  } else {
    clients = db.prepare('SELECT * FROM clients ORDER BY created_at DESC').all();
  }
  res.json({ clients });
});

app.post('/api/clients', requireAnyRole('Admin', 'Accountant'), (req, res) => {
  const { name, contact_email, contact_phone, owner_email } = req.body || {};
  if (!name || !contact_email) {
    return res.status(400).json({ error: 'name and contact_email are required' });
  }
  const db = getDb();
  let firmUserId = null;
  if (req.session.user.role === 'Accountant') {
    firmUserId = req.session.user.id;
  } else if (owner_email) {
    const owner = db.prepare('SELECT id FROM users WHERE email = ?').get(owner_email);
    firmUserId = owner?.id || null;
  }
  const stmt = db.prepare(
    `INSERT INTO clients (firm_user_id, name, contact_email, contact_phone)
     VALUES (@firm_user_id, @name, @contact_email, @contact_phone)`
  );
  const info = stmt.run({
    firm_user_id: firmUserId,
    name,
    contact_email,
    contact_phone: contact_phone || null
  });
  res.status(201).json({ ok: true, id: info.lastInsertRowid });
});

app.get('/api/clients/:id/filings', requireAnyRole('Admin', 'Accountant', 'Client'), (req, res) => {
  const clientId = Number(req.params.id);
  if (!Number.isInteger(clientId)) {
    return res.status(400).json({ error: 'invalid_client_id' });
  }
  const db = getDb();
  const filings = db
    .prepare(
      `SELECT id, tax_year, status, submitted_at, amount_due
       FROM filings WHERE client_id = ? ORDER BY submitted_at DESC`)
    .all(clientId);
  res.json({ filings });
});

app.post('/api/filings', requireAnyRole('Admin', 'Accountant'), (req, res) => {
  const { client_id, tax_year, status, submitted_at, amount_due } = req.body || {};
  if (!client_id || !tax_year || !status) {
    return res.status(400).json({ error: 'client_id, tax_year, and status are required' });
  }
  const db = getDb();
  const stmt = db.prepare(
    `INSERT INTO filings (client_id, tax_year, status, submitted_at, amount_due)
     VALUES (@client_id, @tax_year, @status, @submitted_at, @amount_due)`
  );
  const info = stmt.run({
    client_id,
    tax_year,
    status,
    submitted_at: submitted_at || null,
    amount_due: amount_due || 0
  });
  res.status(201).json({ ok: true, id: info.lastInsertRowid });
});

app.patch('/api/tasks/:id', requireAnyRole('Admin', 'Accountant'), (req, res) => {
  const taskId = Number(req.params.id);
  if (!Number.isInteger(taskId)) {
    return res.status(400).json({ error: 'invalid_task_id' });
  }
  const { status, due_date } = req.body || {};
  if (!status) {
    return res.status(400).json({ error: 'status required' });
  }
  const db = getDb();
  const stmt = db.prepare(
    `UPDATE client_tasks SET status = @status, due_date = COALESCE(@due_date, due_date)
     WHERE id = @id`
  );
  stmt.run({ id: taskId, status, due_date: due_date || null });
  res.json({ ok: true });
});

app.post('/api/documents', requireAnyRole('Admin', 'Accountant'), (req, res) => {
  const { client_id, title, file_path, classification } = req.body || {};
  if (!client_id || !title || !file_path) {
    return res.status(400).json({ error: 'client_id, title, and file_path are required' });
  }
  const db = getDb();
  const stmt = db.prepare(
    `INSERT INTO documents (client_id, title, file_path, classification)
     VALUES (@client_id, @title, @file_path, @classification)`
  );
  const info = stmt.run({
    client_id,
    title,
    file_path,
    classification: classification || null
  });
  res.status(201).json({ ok: true, id: info.lastInsertRowid });
});

app.get('/api/documents/:clientId', requireAnyRole('Admin', 'Accountant', 'Client'), (req, res) => {
  const clientId = Number(req.params.clientId);
  if (!Number.isInteger(clientId)) {
    return res.status(400).json({ error: 'invalid_client_id' });
  }
  const db = getDb();
  const docs = db
    .prepare(
      `SELECT id, title, file_path, classification, uploaded_at
       FROM documents WHERE client_id = ? ORDER BY uploaded_at DESC`
    )
    .all(clientId);
  res.json({ documents: docs });
});

app.post('/api/users/invite', requireRole('Admin'), async (req, res) => {
  try {
    const { full_name, email, password, role } = req.body || {};
    if (!full_name || !email || !password || !role) {
      return res.status(400).json({ error: 'full_name, email, password, and role are required' });
    }
    const user = await createUser({ full_name, email, password, role });
    res.status(201).json({ ok: true, user });
  } catch (err) {
    if (err.message === 'email_taken') {
      return res.status(400).json({ error: 'email_taken' });
    }
    if (err.message === 'invalid_role') {
      return res.status(400).json({ error: 'invalid_role' });
    }
    console.error(err);
    res.status(500).json({ error: 'invite_failed' });
  }
});

app.get('/api/users', requireRole('Admin'), (req, res) => {
  const db = getDb();
  const users = db
    .prepare(
      `SELECT users.id, users.full_name, users.email, users.last_login_at, roles.name as role
       FROM users
       LEFT JOIN roles ON roles.id = users.role_id`
    )
    .all()
    .map(user => ({
      id: user.id,
      full_name: user.full_name,
      email: user.email,
      role: user.role,
      last_login_at: user.last_login_at,
      status: user.last_login_at ? 'Active' : 'Invite pending',
      isSelf: user.id === req.session.user.id
    }));
  res.json({ users });
});

app.patch('/api/users/:id', requireRole('Admin'), (req, res) => {
  const userId = Number(req.params.id);
  if (!Number.isInteger(userId)) {
    return res.status(400).json({ error: 'invalid_user_id' });
  }
  const { role, full_name } = req.body || {};
  if (!role && !full_name) {
    return res.status(400).json({ error: 'no_changes_supplied' });
  }
  if (userId === req.session.user.id && role && role !== 'Admin') {
    return res.status(400).json({ error: 'cannot_downgrade_self' });
  }
  const db = getDb();
  const updates = [];
  const params = { id: userId };
  if (full_name) {
    updates.push('full_name = @full_name');
    params.full_name = full_name;
  }
  if (role) {
    const roleRow = db.prepare('SELECT id FROM roles WHERE name = ?').get(role);
    if (!roleRow) {
      return res.status(400).json({ error: 'invalid_role' });
    }
    updates.push('role_id = @role_id');
    params.role_id = roleRow.id;
  }
  const result = db.prepare(`UPDATE users SET ${updates.join(', ')} WHERE id = @id`).run(params);
  if (result.changes === 0) {
    return res.status(404).json({ error: 'user_not_found' });
  }
  res.json({ ok: true, user: getUserById(userId) });
});

app.delete('/api/users/:id', requireRole('Admin'), (req, res) => {
  const userId = Number(req.params.id);
  if (!Number.isInteger(userId)) {
    return res.status(400).json({ error: 'invalid_user_id' });
  }
  if (userId === req.session.user.id) {
    return res.status(400).json({ error: 'cannot_delete_self' });
  }
  const db = getDb();
  const user = getUserById(userId);
  if (!user) {
    return res.status(404).json({ error: 'user_not_found' });
  }
  db.transaction(() => {
    db.prepare('UPDATE clients SET firm_user_id = NULL WHERE firm_user_id = ?').run(userId);
    db.prepare('UPDATE data_uploads SET uploader_user_id = NULL WHERE uploader_user_id = ?').run(userId);
    db.prepare('UPDATE support_tickets SET user_id = NULL WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM users WHERE id = ?').run(userId);
  })();
  res.json({ ok: true });
});

app.get('/api/alerts', requireAnyRole('Admin', 'Accountant', 'Client'), (req, res) => {
  const db = getDb();
  const alerts = db
    .prepare(
      `SELECT id, severity, category, description, detected_at
       FROM alerts ORDER BY detected_at DESC LIMIT 20`
    )
    .all();
  res.json({ alerts });
});

app.post('/api/uploads', requireAnyRole('Admin', 'Accountant'), upload.single('file'), async (req, res) => {
  const file = req.file;
  if (!file) {
    return res.status(400).json({ error: 'file_required' });
  }
  const defaultClientId = req.body?.client_id ? Number(req.body.client_id) : null;
  try {
    const buffer = fs.readFileSync(file.path);
    const rows = parseFinancialCsv(buffer);
    if (!rows.length) {
      return res.status(400).json({ error: 'file_empty' });
    }
    const { uploadId, clientIds } = persistFinancialUpload({
      uploaderUserId: req.session.user.id,
      defaultClientId,
      originalFilename: file.originalname,
      storedFilename: file.filename,
      records: rows,
      ownerUserId: req.session.user.role === 'Accountant' ? req.session.user.id : null
    });

    const results = [];
    for (const cid of clientIds) {
      try {
        const forecast = await generateClientForecast({ clientId: cid, callModel: callHuggingFace });
        persistForecast(uploadId, cid, forecast);
        results.push({ client_id: cid, forecast });
      } catch (err) {
        if (err.message === 'missing_hf_token') {
          results.push({ client_id: cid, forecast: null, warning: 'AI token missing' });
        } else {
          console.error(err);
          results.push({ client_id: cid, forecast: null, warning: 'AI generation failed' });
        }
      }
    }

    res.status(201).json({ ok: true, uploadId, clients: results });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'upload_failed' });
  }
});

app.get('/api/uploads', requireAnyRole('Admin', 'Accountant'), (req, res) => {
  const limit = Number(req.query.limit) || 15;
  const clientId = req.query.client_id ? Number(req.query.client_id) : null;
  const db = getDb();
  let uploads;
  if (req.session.user.role === 'Admin') {
    uploads = db
      .prepare(
        `SELECT * FROM data_uploads ORDER BY created_at DESC LIMIT ?`
      )
      .all(limit);
  } else {
    uploads = db
      .prepare(
        `SELECT du.* FROM data_uploads du
         LEFT JOIN clients c ON c.id = du.client_id
         WHERE du.uploader_user_id = ?
            OR (c.firm_user_id = ? AND c.firm_user_id IS NOT NULL)
            OR du.client_id IS NULL
         ORDER BY du.created_at DESC LIMIT ?`
      )
      .all(req.session.user.id, req.session.user.id, limit);
  }
  if (Number.isInteger(clientId)) {
    uploads = uploads.filter(upload => upload.client_id === clientId);
  }
  res.json({ uploads });
});

app.delete('/api/uploads/:id', requireAnyRole('Admin', 'Accountant'), (req, res) => {
  const uploadId = Number(req.params.id);
  if (!Number.isInteger(uploadId)) {
    return res.status(400).json({ error: 'invalid_upload_id' });
  }
  const db = getDb();
  const upload = db.prepare('SELECT * FROM data_uploads WHERE id = ?').get(uploadId);
  if (!upload) {
    return res.status(404).json({ error: 'upload_not_found' });
  }
  if (req.session.user.role === 'Accountant') {
    const client = upload.client_id
      ? db.prepare('SELECT firm_user_id FROM clients WHERE id = ?').get(upload.client_id)
      : null;
    const ownsUpload = upload.uploader_user_id === req.session.user.id || client?.firm_user_id === req.session.user.id;
    if (!ownsUpload) {
      return res.status(403).json({ error: 'forbidden' });
    }
  }
  try {
    removeUploadRecords(uploadId);
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'delete_failed' });
  }
});

function getAdminDashboardData() {
  const db = getDb();
  const activeUsers = db.prepare('SELECT COUNT(*) as count FROM users').get().count;
  const pendingInvites = db
    .prepare("SELECT COUNT(*) as count FROM client_tasks WHERE status = 'awaiting_client'")
    .get().count;
  const totalRevenue = db
    .prepare('SELECT SUM(revenue) as total FROM financial_records')
    .get().total || 0;
  const totalExpenses = db
    .prepare('SELECT SUM(expenses + deductions) as total FROM financial_records')
    .get().total || 0;
  const uploads = latestUploads(5);
  const users = db
    .prepare(
      `SELECT users.full_name, users.email, users.last_login_at, roles.name as role
       FROM users
       LEFT JOIN roles ON roles.id = users.role_id`
    )
    .all()
    .map(user => ({
      name: user.full_name,
      role: user.role,
      email: user.email,
      status: user.last_login_at ? 'Active' : 'Invite pending',
      lastActive: user.last_login_at
    }));
  const alerts = db
    .prepare(
      `SELECT severity, category, description, detected_at
       FROM alerts
       ORDER BY detected_at DESC
       LIMIT 5`
    )
    .all();
  const permissions = {
    Admin: ['Manage users & roles', 'Configure security policies', 'Approve exports'],
    Accountant: ['Prepare filings', 'Upload & classify documents', 'Flag anomalies'],
    Client: ['Review filings', 'Reply to advisor requests', 'Access compliance archive']
  };
  return {
    metrics: {
      activeUsers,
      pendingInvites,
      securityScore: 98,
      totalRevenue,
      totalExpenses
    },
    users,
    alerts,
    permissions,
    uploads
  };
}

function getAccountantDashboardData(userId) {
  const db = getDb();
  const clients = db
    .prepare(
      `SELECT clients.id, clients.name, clients.contact_email,
              MIN(client_tasks.due_date) as next_deadline
       FROM clients
       LEFT JOIN client_tasks ON client_tasks.client_id = clients.id
       WHERE clients.firm_user_id = ?
       GROUP BY clients.id`
    )
    .all(userId)
    .map(client => ({
      id: client.id,
      name: client.name,
      status: getClientStatus(client.id),
      nextDeadline: client.next_deadline,
      risk: getClientRisk(client.id)
    }));

  const tasks = db
    .prepare(
      `SELECT client_tasks.*, clients.name as client_name
       FROM client_tasks
       LEFT JOIN clients ON clients.id = client_tasks.client_id
       WHERE clients.firm_user_id = ?`
    )
    .all(userId);

  const uploads = latestUploads(10);

  return {
    worklist: {
      toPrepare: tasks.filter(t => t.status === 'to_prepare'),
      inReview: tasks.filter(t => t.status === 'in_review'),
      awaitingClient: tasks.filter(t => t.status === 'awaiting_client')
    },
    clients,
    uploads
  };
}

function getClientStatus(clientId) {
  const db = getDb();
  const pending = db
    .prepare(
      `SELECT COUNT(*) as count
       FROM client_tasks
       WHERE client_id = ? AND status IN ('to_prepare','in_review','awaiting_client')`
    )
    .get(clientId).count;
  if (pending === 0) return 'On track';
  return 'Needs attention';
}

function getClientRisk(clientId) {
  const db = getDb();
  const anomalies = db
    .prepare(
      `SELECT COUNT(*) as count FROM ai_anomalies WHERE client_id = ?`
    )
    .get(clientId).count;
  if (anomalies >= 3) return 'High';
  if (anomalies >= 1) return 'Medium';
  return 'Low';
}

function getClientDashboardData(userId) {
  const db = getDb();
  const user = getUserById(userId);
  const client = db
    .prepare(
      `SELECT clients.*
       FROM clients
       LEFT JOIN users ON users.id = clients.firm_user_id
       WHERE clients.id = (SELECT client_id FROM support_tickets WHERE user_id = ? LIMIT 1)
          OR clients.contact_email = ?`
    )
    .get(userId, user.email);

  const clientId = client?.id;

  const filings = clientId
    ? db
        .prepare(
          `SELECT tax_year, status, submitted_at, amount_due
           FROM filings WHERE client_id = ? ORDER BY submitted_at DESC`
        )
        .all(clientId)
    : [];

  const tasks = clientId
    ? db
        .prepare(
          `SELECT title, status, due_date
           FROM client_tasks
           WHERE client_id = ?
           ORDER BY created_at DESC`
        )
        .all(clientId)
    : [];

  const balanceDue = filings
    .filter(f => f.status === 'pending_payment')
    .reduce((sum, f) => sum + (f.amount_due || 0), 0);

  const upcoming = tasks
    .filter(t => t.status !== 'completed')
    .map(t => t.due_date)
    .filter(Boolean)
    .sort()[0];

  const forecast = clientId
    ? db
        .prepare(
          `SELECT * FROM ai_forecasts WHERE client_id = ? ORDER BY generated_at DESC LIMIT 1`
        )
        .get(clientId)
    : null;

  const anomalies = clientId
    ? db
        .prepare(
          `SELECT description, severity, score, generated_at
           FROM ai_anomalies WHERE client_id = ? ORDER BY generated_at DESC LIMIT 10`
        )
        .all(clientId)
    : [];

  return {
    user,
    client,
    metrics: {
      upcomingDeadline: upcoming || null,
      balanceDue,
      documentsNeeded: tasks.filter(t => t.status === 'awaiting_client').length
    },
    filings,
    tasks,
    forecast,
    anomalies,
    uploads: clientId ? latestUploads(5, clientId) : []
  };
}

function requireAnyRole(...roles) {
  return (req, res, next) => {
    if (!req.session?.user) {
      return res.status(401).json({ error: 'auth_required' });
    }
    if (!roles.includes(req.session.user.role)) {
      return res.status(403).json({ error: 'forbidden' });
    }
    return next();
  };
}

// Serve static site (index.html and assets)
app.use('/', express.static(STATIC_DIR));

app.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`);
});

