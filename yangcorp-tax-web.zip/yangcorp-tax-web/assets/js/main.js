document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.nav-toggle');
  const menu = document.querySelector('#primary-menu');
  const year = document.querySelector('#year');
  const form = document.querySelector('#inquiry-form');
  const formStatus = document.querySelector('#form-status');

  if (year) {
    year.textContent = new Date().getFullYear().toString();
  }

  if (toggle && menu) {
    toggle.addEventListener('click', () => {
      const expanded = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', (!expanded).toString());
      menu.classList.toggle('open');
    });
  }

  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const data = {
        name: form.name.value.trim(),
        email: form.email.value.trim(),
        message: form.message.value.trim()
      };
      formStatus.textContent = 'Submitting...';
      try {
        const res = await fetch('/api/inquiries', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data)
        });
        const json = await res.json();
        if (!res.ok) throw new Error(json.error || 'Request failed');
        form.reset();
        formStatus.textContent = 'Thanks! We will reach out shortly.';
      } catch (err) {
        formStatus.textContent = 'Submission failed. Please try again.';
      }
    });
  }
});


