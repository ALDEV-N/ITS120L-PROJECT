﻿(function(){
  // Role-aware AI endpoint and graceful fallback for 502 errors
  const role = (document.body?.dataset?.role || 'accountant').toLowerCase();
  const aiEndpoint = `/api/dashboard/ai/${role === 'admin' ? 'admin' : 'accountant'}`;

  async function fetchAiInsights() {
    try {
      const res = await fetch(aiEndpoint, {cache: 'no-store'});
      if (res.status === 502) {
        const text = await res.text().catch(()=>'<no body>');
        console.error(`${aiEndpoint} returned 502:`, text);
        showError(`AI service unavailable (502). Showing cached insights.`);
        return getFallbackInsights();
      }
      if (!res.ok) {
        const text = await res.text().catch(()=>'<no body>');
        console.error(`${aiEndpoint} error ${res.status}:`, text);
        showError(`AI endpoint error ${res.status}.`);
        return getFallbackInsights();
      }
      const data = await res.json();
      return Array.isArray(data) ? data : (data.items || getFallbackInsights());
    } catch (err) {
      console.error('Network error fetching AI insights:', err);
      showError('Network error contacting AI service.');
      return getFallbackInsights();
    }
  }

  function getFallbackInsights(){
    return [
      {id:'f1', title:'Check missing receipts', summary:'Several clients have uncategorized expenses.'},
      {id:'f2', title:'High refund risk', summary:'Anomalous refunds detected for client #102.'}
    ];
  }

  function showError(msg){
    const status = document.querySelector('#form-status') || document.querySelector('#accountant-insights');
    if (status) {
      const el = document.createElement('div');
      el.className = 'error muted';
      el.textContent = msg;
      status.insertAdjacentElement('afterbegin', el);
    }
  }

  function renderInsights(items){
    const container = document.getElementById('accountant-insights');
    if (!container) return;
    container.innerHTML = '';
    items.forEach(it=>{
      const card = document.createElement('div');
      card.className = 'insight-card card';
      card.innerHTML = `<h4>${escapeHtml(it.title || 'Insight')}</h4><p>${escapeHtml(it.summary || (it.message || ''))}</p>`;
      container.appendChild(card);
    });
  }

  function escapeHtml(s){
    return String(s).replace(/[&<>"']/g, c=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
  }

  // Initialize
  document.addEventListener('DOMContentLoaded', async ()=>{
    const insights = await fetchAiInsights();
    renderInsights(insights);
  });

  // Expose for debugging
  window.__fetchAiInsights = fetchAiInsights;
})();
